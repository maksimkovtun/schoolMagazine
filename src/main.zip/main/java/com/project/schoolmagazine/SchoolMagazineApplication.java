package com.project.schoolmagazine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolMagazineApplication {
	public static void main(String[] args) {
		SpringApplication.run(SchoolMagazineApplication.class, args);
	}
}
